## 一、Function（Skill）定义

### 1.1 交给模型的 JSON Schema

两个 Skill 都以 OpenAI tools 格式声明。description 写清「什么时候该调用、什么时候不该调用」，参数用 JSON Schema 描述类型与约束 —— 模型只能依靠这些文字决定是否调用、传什么参数。

```json
[
  {
    "type": "function",
    "function": {
      "name": "check_inventory",
      "description": "查询电子书城本店的实时库存与售价。当用户询问某本书还有多少本、是否有货、能不能买到、本店卖多少钱，或需要判断库存是否足够时调用。必须先从用户的话里拿到 ISBN 再调用；如果用户只给了书名，不要猜测 ISBN，先向用户索要。",
      "parameters": {
        "type": "object",
        "properties": {
          "isbn": {
            "type": "string",
            "description": "图书的国际标准书号，10 位或 13 位，可带连字符，例如 978-3-00-000000-4 或 9783000000004。"
          }
        },
        "required": [
          "isbn"
        ],
        "additionalProperties": false
      }
    }
  },
  {
    "type": "function",
    "function": {
      "name": "get_competitor_price",
      "description": "查询其他平台（竞品）对同一本书的报价，用于和本店价格做对比。仅当用户明确要求比价、询问别家卖多少钱时才调用；如果只是问本店库存，不要调用本函数。",
      "parameters": {
        "type": "object",
        "properties": {
          "isbn": {
            "type": "string",
            "description": "图书的 ISBN，与 check_inventory 使用的是同一个值。"
          }
        },
        "required": [
          "isbn"
        ],
        "additionalProperties": false
      }
    }
  }
]
```

### 1.2 本地模拟实现

- `check_inventory`：先校验 ISBN 形态（去掉连字符后必须是 10 位或 13 位数字），再查数据源。数据源默认是内置的模拟目录 `MockInventoryBackend`，数据取自项目 `springboot-ebook/src/main/resources/data.sql` 的演示数据；设置环境变量 `BOOKSTORE_API_BASE` 后自动切换为 `HttpInventoryBackend`，直接读电子书城真实后端的 `GET /api/v1/books`。两者返回同一结构，上层不用改。
- `get_competitor_price`：模拟竞品比价接口，具备网络耗时、上游抖动、上游整体故障三种行为。报价由 ISBN 的数字位稳定推导，同一本书每次得到同一组结果，演示与测试都可复现。

这里刻意不校验 EAN-13 校验位：项目演示数据里的 ISBN 是构造出来的，校验位并不合法，开启校验位检查会把全部演示数据误判成非法输入。

## 二、配置给大模型的 Tool 列表

每次请求都把上面两个 Schema 放进 `tools` 字段，`tool_choice` 设为 `auto`，由模型自行决定是否调用、调用哪一个、传什么参数。实际发出的请求体形态：

```json
{
  "model": "<LLM_MODEL>",
  "messages": [
    {
      "role": "system",
      "content": "你是「E-BookStore 电子书城」的在线客服助手……"
    },
    {
      "role": "user",
      "content": "帮我查一下 ISBN为978-3-00-000000-4 的书还有多少本，顺便看看别家卖多少钱"
    }
  ],
  "tools": [
    {
      "type": "function",
      "function": {
        "name": "check_inventory",
        "description": "查询电子书城本店的实时库存与售价。当用户询问某本书还有多少本、是否有货、能不能买到、本店卖多少钱，或需要判断库存是否足够时调用。必须先从用户的话里拿到 ISBN 再调用；如果用户只给了书名，不要猜测 ISBN，先向用户索要。",
        "parameters": {
          "type": "object",
          "properties": {
            "isbn": {
              "type": "string",
              "description": "图书的国际标准书号，10 位或 13 位，可带连字符，例如 978-3-00-000000-4 或 9783000000004。"
            }
          },
          "required": [
            "isbn"
          ],
          "additionalProperties": false
        }
      }
    },
    {
      "type": "function",
      "function": {
        "name": "get_competitor_price",
        "description": "查询其他平台（竞品）对同一本书的报价，用于和本店价格做对比。仅当用户明确要求比价、询问别家卖多少钱时才调用；如果只是问本店库存，不要调用本函数。",
        "parameters": {
          "type": "object",
          "properties": {
            "isbn": {
              "type": "string",
              "description": "图书的 ISBN，与 check_inventory 使用的是同一个值。"
            }
          },
          "required": [
            "isbn"
          ],
          "additionalProperties": false
        }
      }
    }
  ],
  "tool_choice": "auto"
}
```

客户端有两条等价路径：优先走 `openai` SDK（`OpenAICompatibleClient`），SDK 不可用时退回只用标准库的 `HttpChatClient`。两者请求体完全一致，改 `base_url` 即可切换 OpenAI / DeepSeek / 通义千问兼容模式等供应商。

## 三、函数调用的拦截与回传

`BookstoreAssistant.chat()` 是「拦截模型输出 → 本地执行 → 结果回传 → 生成回答」的落点，一轮用户提问内的流程：

1. 组装 messages（system + 历史 + 本轮提问），连同 Tool 列表发给模型；
2. 模型返回的 assistant 消息里若带 `tool_calls`，不发给用户，而是拦截下来；
3. 打印函数名与参数，交给 `ToolRegistry.dispatch` 本地执行；
4. 把执行结果包装成 `role: "tool"` 的消息追加进上下文，回到第 1 步；
5. 模型不再要求调用函数时，它给出的自然语言内容就是最终回复。

被拦截的每一次调用都会生成一条 `ToolEvent`。服务端日志（`docs/logs/server.log`）：

```text
2026-09-28 15:03:42,620 INFO ebook.assistant.server | [4f8391bba621] 用户提问：帮我查一下 ISBN为978-3-00-000000-4 的书还有多少本，顺便看看别家卖多少钱
2026-09-28 15:03:42,620 INFO ebook.assistant.server | [4f8391bba621] [TOOL CALL] check_inventory({"isbn": "978-3-00-000000-4"}) -> ok (0ms) round=1
2026-09-28 15:03:43,025 INFO ebook.assistant.server | [4f8391bba621] [TOOL CALL] get_competitor_price({"isbn": "978-3-00-000000-4"}) -> ok (405ms) round=2
2026-09-28 15:03:43,026 INFO ebook.assistant.server | [4f8391bba621] 回复：《Introduction To Algorithms》（Thomas H. Cormen，ISBN 9783000000004）本店当前库存 30 本，状态「有货」，售价 99 元。 其他平台报价：博文轩 76 元（有货，2 天到）；云书房 82 元（有货，1 天到）；知微书城 71 元（有货，4 天到）。最低价出现在 知微书城。 本店比最低价贵 28 元。
2026-09-28 15:03:43,060 INFO ebook.assistant.server | [3f4b55b510e3] 用户提问：ISBN为12345 的书还有多少本
2026-09-28 15:03:43,060 INFO ebook.assistant.server | [3f4b55b510e3] [TOOL CALL] check_inventory({"isbn": "12345"}) -> failed:INVALID_ISBN_FORMAT (0ms) round=1
2026-09-28 15:03:43,060 INFO ebook.assistant.server | [3f4b55b510e3] 回复：本店库存没查到：ISBN '12345' 格式不合法：去掉连字符后应为 10 位或 13 位数字。 你给的 ISBN 位数不对，麻烦核对一下再发给我。
```

模型给出的 `arguments` 是字符串，且不保证是合法 JSON（长参数被截断、引号混用都很常见）。`ToolCallRequest.parse_arguments()` 永远返回 `(参数, 错误)` 二元组，解析失败时生成一条 `INVALID_JSON_ARGUMENTS` 的 tool 消息回传，让模型重新表述，而不是让整个对话崩掉。

## 四、前端智能助手对话界面

界面接在电子书城前端：左侧菜单新增「客服助手」，路由 `/assistant`，沿用站内既有的 React Router Data API 约定（`loader` 读数据、`action` 处理顶栏搜索），对话本身是客户端状态，直接调用助手后端的 `POST /api/assistant/chat`。

页面把拦截到的函数名与参数做成了可见的卡片：函数名、参数、成功或失败、耗时、可展开的完整返回值；失败时额外显示回传给模型的纠错提示。

![](/Users/yuguanting/Documents/EBook/作业2/docs/screenshots/ui-01-normal.png){width=14cm}

![](/Users/yuguanting/Documents/EBook/作业2/docs/screenshots/ui-02-self-correction.png){width=14cm}

![](/Users/yuguanting/Documents/EBook/作业2/docs/screenshots/ui-03-retry.png){width=14cm}

![](/Users/yuguanting/Documents/EBook/作业2/docs/screenshots/ui-04-no-isbn.png){width=14cm}

以上截图不是把对话记录画成图片，而是把前后端跑起来、点击页面上的示例问题按钮、让后端真的跑一遍 Function Calling 之后截下来的，见 `scripts/capture_ui.py`。

## 五、异常处理与 Self-Correction

### 5.1 错误码与期望的模型行为

| 错误码 | 触发条件 | retryable | 期望的模型行为 |
|---|---|---|---|
| `INVALID_ARGUMENT` | 缺少 isbn、类型不对、函数不存在、参数名不在 schema 里 | 否 / 是 | 按 schema 重新组织参数 |
| `INVALID_ISBN_FORMAT` | ISBN 去连字符后不是 10 位或 13 位数字 | 否 | 复述原值请用户确认，绝不自行补位 |
| `ISBN_NOT_FOUND` | 格式合法但书店目录里没有 | 否 | 如实告知未收录，不虚构书名与库存 |
| `UPSTREAM_TIMEOUT` | 比价接口耗时超过阈值，或上游抖动 | 是 | 原样重试一次 |
| `UPSTREAM_UNAVAILABLE` | 比价渠道整体不可用 | 否 | 不重试，告知用户只拿到本店价格 |
| `TOOL_INTERNAL_ERROR` | 工具内部未预期异常 | 否 | 告知用户暂时查不到 |

三条防线：工具层的 `dispatch` 把所有失败收敛成 `{"ok": false, "error": {...}}`，异常栈对模型没有意义、`error.hint` 才有；循环层设连续失败上限（默认 3 次）与往返轮次上限（默认 6 轮），避免请求挂死；System Prompt 把 `retryable` 的语义、「不许编造库存」「不许猜 ISBN」写成明确规则，让模型知道该重试还是该换策略。

### 5.2 五个场景的真实运行链路

以下内容由 `python -m backend.cli --demo` 直接产出（`docs/demo-trace.json`），未经手工编辑。

**场景 1　正常链路：本店库存 + 竞品比价**

用户提问：`帮我查一下 ISBN为978-3-00-000000-4 的书还有多少本，顺便看看别家卖多少钱`

| 轮次 | 被拦截的函数调用 | 执行结果 | 耗时 |
|---|---|---|---|
| 第 1 轮 | `check_inventory({"isbn": "978-3-00-000000-4"})` | ✅ 库存 30 本，99 元 | 0 ms |
| 第 2 轮 | `get_competitor_price({"isbn": "978-3-00-000000-4"})` | ✅ 最低价 71 元 | 405 ms |

助手回复：

```text
《Introduction To Algorithms》（Thomas H. Cormen，ISBN 9783000000004）本店当前库存 30 本，状态「有货」，售价 99 元。
其他平台报价：博文轩 76 元（有货，2 天到）；云书房 82 元（有货，1 天到）；知微书城 71 元（有货，4 天到）。最低价出现在 知微书城。
本店比最低价贵 28 元。
```

**场景 2　非法入参：ISBN 位数不对，模型应改为向用户确认**

用户提问：`ISBN为12345 的书还有多少本，顺便看看别家卖多少钱`

| 轮次 | 被拦截的函数调用 | 执行结果 | 耗时 |
|---|---|---|---|
| 第 1 轮 | `check_inventory({"isbn": "12345"})` | ❌ INVALID_ISBN_FORMAT，retryable=false | 0 ms |

助手回复：

```text
本店库存没查到：ISBN '12345' 格式不合法：去掉连字符后应为 10 位或 13 位数字。
你给的 ISBN 位数不对，麻烦核对一下再发给我。
```

**场景 3　上游抖动：比价接口第一次超时，重试后成功**

用户提问：`ISBN为978-7-00-000000-8 的书还有几本？另外帮我对比一下其他平台的价格`

| 轮次 | 被拦截的函数调用 | 执行结果 | 耗时 |
|---|---|---|---|
| 第 1 轮 | `check_inventory({"isbn": "978-7-00-000000-8"})` | ✅ 库存 15 本，72 元 | 0 ms |
| 第 2 轮 | `get_competitor_price({"isbn": "978-7-00-000000-8"})` | ❌ UPSTREAM_TIMEOUT，retryable=true | 404 ms |
| 第 3 轮 | `get_competitor_price({"isbn": "978-7-00-000000-8"})` | ✅ 最低价 79 元 | 403 ms |

助手回复：

```text
《量子物理》（吕智国，ISBN 9787000000008）本店当前库存 15 本，状态「有货」，售价 72 元。
其他平台报价：博文轩 84 元（有货，2 天到）；云书房 90 元（有货，1 天到）；知微书城 79 元（缺货，4 天到）。最低价出现在 知微书城。
本店比最低价便宜 7 元。
```

**场景 4　上游故障：比价渠道整体不可用，重试无意义，应如实告知**

用户提问：`ISBN为978-2-00-000000-3 的库存和竞品价格分别是多少`

| 轮次 | 被拦截的函数调用 | 执行结果 | 耗时 |
|---|---|---|---|
| 第 1 轮 | `check_inventory({"isbn": "978-2-00-000000-3"})` | ✅ 库存 4 本，79 元 | 0 ms |
| 第 2 轮 | `get_competitor_price({"isbn": "978-2-00-000000-3"})` | ❌ UPSTREAM_UNAVAILABLE，retryable=false | 0 ms |

助手回复：

```text
《Intorduction to Computing Systems》（Yale N. Patt，ISBN 9782000000003）本店当前库存 4 本，状态「库存紧张」，售价 79 元。
库存偏紧，要买的话建议尽快下单。
比价接口这次没返回结果：竞品比价服务对 ISBN 9782000000003 返回 503。
```

**场景 5　信息不足：用户只给书名没给 ISBN，模型应先索要**

用户提问：`《量子物理》还有货吗？`

模型没有调用任何函数，直接向用户追问缺失的信息。

助手回复：

```text
我需要 ISBN 才能查。请把书的 ISBN 发给我，10 位或 13 位都可以。
```

### 5.3 命令行完整输出

![](/Users/yuguanting/Documents/EBook/作业2/docs/screenshots/terminal-agent-demo.png){width=14cm}
